package com.hspedu.hsperp;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class HspErpApplication {
    public static void main(String[] args) {

        System.out.println("HspErpApplication hello100");
        System.out.println("HspErpApplication hello200 for v2.0");

    }
}
