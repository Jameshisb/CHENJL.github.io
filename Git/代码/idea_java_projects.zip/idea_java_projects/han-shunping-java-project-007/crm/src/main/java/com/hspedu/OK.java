package com.hspedu;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class OK {
    public static void main(String[] args) {
        System.out.println("OK");
    }
}
