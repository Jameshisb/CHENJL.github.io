package com.hspedu.hspsns;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class Hello {
    public static void main(String[] args) {
        System.out.println("Hello1");
        System.out.println("Hello2");
        System.out.println("Hello3");
    }
}
