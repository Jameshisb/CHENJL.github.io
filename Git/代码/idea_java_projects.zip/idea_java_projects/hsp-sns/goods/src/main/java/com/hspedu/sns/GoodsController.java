package com.hspedu.sns;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class GoodsController {

    //这是一个GoodsController
}
